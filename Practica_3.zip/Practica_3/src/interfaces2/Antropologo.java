package interfaces2;

public class Antropologo implements Salariable,Trabajable {

	public Antropologo()
	{
		
	}
	public String getNombre() {
		
		return "Pedro Paramo";
	}

	
	public int getEdad() {
		
		return 99;
	}

	
	public double getSalario() {
		
		return 99999.99;
	}

}
