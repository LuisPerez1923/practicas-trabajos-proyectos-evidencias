package interfaces2;

public interface Trabajable {

	String getNombre();
	int getEdad();
	
}
