package interfaces2;

public interface Salariable {
	
	double getSalario();

}
