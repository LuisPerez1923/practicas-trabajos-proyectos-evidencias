package interfaces2;



public class Principal {

	public static void main(String[] args) {
		
		Ingeniero ing2=new Ingeniero();
		Antropologo ant2=new Antropologo();
		
		System.out.println("Nombre del ingeniero: " + ing2.getNombre());
		System.out.println("Edad: " + ing2.getEdad());
		System.out.println("Salario: " + ing2.getSalario());
		
		
		System.out.println("Nombre del antropologo: " + ant2.getNombre());
		System.out.println("Edad: " + ant2.getEdad());
		System.out.println("Salario: " + ant2.getSalario());

	}

}
