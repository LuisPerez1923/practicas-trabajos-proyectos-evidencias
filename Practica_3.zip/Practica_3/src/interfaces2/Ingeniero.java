package interfaces2;

public class Ingeniero implements Salariable, Trabajable{

	public Ingeniero()
	{
		
	}
	public String getNombre() {
		
	return "Juan Carlos Estrada";
	}

	
	public int getEdad() {
		
		return 77;
	}

	
	public double getSalario() {
		
		return 52400.13;
	}

}
