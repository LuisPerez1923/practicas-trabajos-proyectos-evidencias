package interfaces;


public interface Salariable {
	

	double getSalario();

}
