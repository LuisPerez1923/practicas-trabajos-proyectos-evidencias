package interfaces;

public class Antropologo extends Trabajador implements Salariable  {

	public Antropologo(String cadena, int dato)
	{
		super(cadena,dato);
	}
	
	public double getSalario()
	{
		return 15720.10;
	}
}
