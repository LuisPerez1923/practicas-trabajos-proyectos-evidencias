package interfaces;


public class Principal {

	public static void main(String[] args) {
		

		Ingeniero inge=new Ingeniero("Pepe Lopez", 55);
		Antropologo antr=new Antropologo("Luis Rodriguez", 72);
		
		System.out.println("Nombre del ingeniero: " + inge.getNombre());
		System.out.println("Edad: " + inge.getEdad());
		System.out.println("Salario: " + inge.getSalario());
		
		
		System.out.println("Nombre del antropologo: " + antr.getNombre());
		System.out.println("Edad: " + antr.getEdad());
		System.out.println("Salario: " + antr.getSalario());
		
		
	}

}
