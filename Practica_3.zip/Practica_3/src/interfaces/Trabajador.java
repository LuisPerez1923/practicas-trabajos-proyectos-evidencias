package interfaces;

public class Trabajador {
	private String nombre;
	private int edad;
	
	Trabajador(String cadena, int dato)
	{
		nombre=cadena;
		edad=dato;
		
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public int getEdad()
	{
		return edad;
	}
	

}
