package interfaces;

public class Ingeniero extends Trabajador implements Salariable {

	public Ingeniero(String cadena, int dato)
	{
		super(cadena,dato);
	}
	
	public double getSalario()
	{
		return 22630.10;
	}
}
