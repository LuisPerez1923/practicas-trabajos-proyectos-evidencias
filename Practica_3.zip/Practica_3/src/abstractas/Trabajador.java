package abstractas;

public abstract class Trabajador {
	private String nombre;
	private int edad;
	
	Trabajador (String cadena, int dato)
	{
		nombre=cadena;
		edad=dato;
		
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public int getEdad()
	{
		return edad;
	}
	
	public abstract double getSalario();
	
	//Trabajador tra=new Trabajador("Paco",55); //no se puede crear objetos  desde la misma super clase

}
