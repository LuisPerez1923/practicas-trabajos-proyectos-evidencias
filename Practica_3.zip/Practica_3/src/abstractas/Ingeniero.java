package abstractas;

public class Ingeniero extends Trabajador {
	
	public Ingeniero(String cadena, int dato)
	{
		super(cadena,dato);
	}
	
	//Trabajador tra=new Trabajador("Paco",55);  no se pueden crear objetos desde subclases
	
	public double getSalario()
	{
		return 2455000.75;
	}

}
