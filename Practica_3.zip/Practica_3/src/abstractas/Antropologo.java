package abstractas;

public class Antropologo extends Trabajador{
	
	
	public Antropologo(String cadena, int dato)
	{
		super(cadena,dato);
	}
	
	public double getSalario()
	{
		return 13570.25;
	}
}
