package abstractas;

public class Principal {

	public static void main(String[] args) {
		
		Ingeniero ing=new Ingeniero("Pedro Lopez", 47);
		Antropologo ant=new Antropologo("Juan Garcia", 39);
		
		System.out.println("Nombre del ingeniero: " + ing.getNombre());
		System.out.println("Edad: " + ing.getEdad());
		System.out.println("Salario: " + ing.getSalario());
		
		
		System.out.println("Nombre del antropologo: " + ant.getNombre());
		System.out.println("Edad: " + ant.getEdad());
		System.out.println("Salario: " + ant.getSalario());
		
		//Trabajador tra=new Trabajador("Paco",55);   no se pueden crear objetos en el main
		
		

	}

}
