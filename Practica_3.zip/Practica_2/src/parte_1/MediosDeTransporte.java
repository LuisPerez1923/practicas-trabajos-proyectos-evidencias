package parte_1;

public class MediosDeTransporte {

	private String alcance;
    private  double precio;
    
    MediosDeTransporte(String alcance, double precio)
    {
    	this.alcance=alcance;
    	this.precio=precio;
    }
    
    String getAlcance()
    {
    	return " Alcance: " +alcance;
    }
    
    String getPrecio()
    {
    	return "  Precio: " + precio;
    }
}
