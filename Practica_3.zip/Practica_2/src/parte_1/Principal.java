package parte_1;

public class Principal {

	public static void main(String[] args) {
		
		Bicicleta bic1= new Bicicleta("personal",5000.12,2,"BMX");
		Bicicleta bic2= new Bicicleta("personal",25410.12,2,"Ruta");
		Auto au1=new Auto("Personal",500000.99,4,"Deportivo");
		Auto au2=new Auto("Personal",353200.99,4,"Familiar");
		System.out.println("Bicicleta 1: " + bic1.getInformacion());
		System.out.println("Bicicleta 2: " + bic2.getInformacion());
		System.out.println("Auto: " + au1.getInformacion());
		System.out.println("Camioneta: " + au2.getInformacion());
		
		MediosDeTransporte med=new MediosDeTransporte("Masivo",1000000);
		Terrestre ter=new Terrestre("Masivo", 10, 16);
		
		System.out.println(med.getAlcance() + med.getPrecio());
		System.out.println(ter.getRuedas());
	}

}
