package parte_1;

public class Terrestre extends MediosDeTransporte{
	
	private int ruedas;
	
	Terrestre(String alcance, double precio, int ruedas)
	{
		super(alcance,precio);
		this.ruedas=ruedas;
	}
	
	String getRuedas()
	{
		return super.getAlcance() + super.getPrecio() + "  No. de Ruedas: " +  ruedas;
	}

}
