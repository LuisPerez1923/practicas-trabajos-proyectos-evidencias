package parte_1;

public class Bicicleta extends Terrestre {
	
	private String tipo;
	
	Bicicleta(String alcance, double precio, int ruedas, String tipo)
	{
        super(alcance,precio,ruedas);
		this.tipo=tipo;
		
	}

	String getInformacion()
	{
		return super.getRuedas() +"  Tipo: "+ tipo;
	}
}
