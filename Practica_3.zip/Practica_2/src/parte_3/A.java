package parte_3;

public class A {

	 int i,j;
	 
	 A(int a, int b)
	 {
		 i=a;
		 j=b;
	 }
	 
	 void show()
	 {
		 System.out.println("i y j: " + i + " y " + j );
	 }
}
