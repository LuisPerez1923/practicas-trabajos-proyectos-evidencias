package parte_3;

public class Principal {

	public static void main(String[] args) {

		
		B subOb=new B(1,2,3);
		subOb.show();
		
	}

}
