package parte_2;

public class OverloadDemo {
	
	void test()
	{
		System.out.println("En este metodo no hay atributos");
		
	}
	void test(int a, int b)
	{
		System.out.println("Enteros a y b: "  + a + " y " + b);
	}
	void test(double a)
	{
		System.out.println("Double a: " + a);
	}

}
