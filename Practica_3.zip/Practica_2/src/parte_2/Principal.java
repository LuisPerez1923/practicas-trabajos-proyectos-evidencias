package parte_2;

public class Principal {
	
	

	public static void main(String[] args) {
		OverloadDemo over=new OverloadDemo();
		
		double i=17;
		
		over.test();
		over.test(100);
        over.test(5, 10); 
        
        over.test(i);
	}

}
