package parte_4;

public class Principal {

	public static void main(String[] args) {
		
		Figura fig=new Figura(10,10);
		Rectangulo rec=new Rectangulo(5,10);
		Triangulo tri=new Triangulo(1,10);
		
		Figura s;
		s=fig;
		s.area();
		
		s=rec;
		System.out.println(s.area());
		
		s=tri;
		System.out.println(s.area());
		
	}

}
