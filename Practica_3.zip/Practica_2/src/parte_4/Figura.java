package parte_4;

public class Figura {
	double dim1,dim2;
	
	Figura(int a, int b)
	{
		dim1=a;
		dim2=b;
		
	}
	
	double area()
	{
		System.out.println("El area de la figura no esta definido ");
		return 0;
	}
	
}
