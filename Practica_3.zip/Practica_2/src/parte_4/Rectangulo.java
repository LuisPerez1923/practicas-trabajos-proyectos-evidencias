package parte_4;

public class Rectangulo extends Figura{
	
	Rectangulo(int a, int b)
	{
		super(a,b);
	}
	double area()
	{
		System.out.println("Dentro del metodo area para un rectangulo: ");
		return dim1*dim2;
	}

}
