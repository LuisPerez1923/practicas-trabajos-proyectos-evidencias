package parte_4;

public class Triangulo extends Figura{
	
	Triangulo(int a, int b)
	{
		super(a,b);
	}
	
	double area()
	{
		System.out.println("Dentro del metodo del area de un triangulo: ");
		return ((dim1*dim2)/2);
	}
	

}
