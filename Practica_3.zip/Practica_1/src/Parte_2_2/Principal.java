package Parte_2_2;


public class Principal {

	
		
		public static void main(String[] args) 
		{
			// TODO Auto-generated method stub
			Racional R1= new Racional();
			Racional R2= new Racional();
			Racional R3= new Racional();
			
			R1.numerador=1;
			R1.denominador=2;
			
			R2.numerador=3;
			R2.denominador=4;
			
			R3=Racional.sumaRacionales(R1,R2);
			
			System.out.println("El resultado de la suma es: " + R1.numerador + "/" + R1.denominador+ " + " + R2.numerador + "/" + R2.denominador+ " = " + R3.numerador + "/" + R3.denominador);
		

	}

}
