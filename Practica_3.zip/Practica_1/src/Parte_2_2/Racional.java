package Parte_2_2;

public class Racional {

	
	 int numerador;
	 int denominador;
	
	static Racional sumaRacionales (Racional R1, Racional R2) 
	{
		Racional R4=new Racional();
		R4.denominador=(R1.denominador)*(R2.denominador);
		R4.numerador=((R1.numerador)*(R2.denominador))+((R1.denominador)*(R2.numerador));
		
		
		return R4;
	}
}
