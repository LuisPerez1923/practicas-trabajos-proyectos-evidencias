package Parte_2_3;



public class Principal {

	static int res1,res2;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Racional R1= new Racional();
		Racional R2= new Racional();
	
		
		R1.setValores(1,2);
		
		R2.setValores(3,4);
		
		res1=Racional.calculaNumerador(R1,R2);
		res2=Racional.calculaDenominador(R1,R2);
		
		System.out.println("El resultado de la suma es: " + res1 + "/" + res2 );
	}

}
