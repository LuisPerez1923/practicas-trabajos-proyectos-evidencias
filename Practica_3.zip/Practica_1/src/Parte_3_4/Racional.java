package Parte_3_4;


public class Racional {

	private int numerador;
	private int denominador;
	
    Racional(int numerador, int denominador)
    {
    	this.numerador=numerador;
    	this.denominador=denominador;
    }

	
	 static int calculaDenominador (Racional R1, Racional R2) 
	{
		Racional R4=new Racional(0,0);
		R4.denominador=(R1.denominador)*(R2.denominador);
	return R4.denominador;
	}
		
		
	static int calculaNumerador (Racional R1, Racional R2) 
		{
			Racional R4=new Racional(0,0);
            R4.numerador=((R1.numerador)*(R2.denominador))+((R1.denominador)*(R2.numerador));
		return R4.numerador;
		}
	
}
