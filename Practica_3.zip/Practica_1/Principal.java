package Parte_3_4;


public class Principal {
	
	static int res1,res2;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Racional R1= new Racional(1,2);
		Racional R2= new Racional(3,4);
	
		
		
		res1=Racional.calculaNumerador(R1,R2);
		res2=Racional.calculaDenominador(R1,R2);
		
		System.out.println("El resultado de la suma es: " + res1 + "/" + res2 );

	}

}
