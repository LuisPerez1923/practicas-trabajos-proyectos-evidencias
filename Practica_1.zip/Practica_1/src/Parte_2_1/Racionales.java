package Parte_2_1;

public class Racionales {
	
	 int numerador;
	 int denominador;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Racionales R1= new Racionales();
		Racionales R2= new Racionales();
		Racionales R3= new Racionales();
		
		R1.numerador=1;
		R1.denominador=2;
		
		R2.numerador=3;
		R2.denominador=4;
		
		R3=sumaRacionales(R1,R2);
		
		System.out.println("El resultado de la suma es: " + R1.numerador + "/" + R1.denominador+ " + " + R2.numerador + "/" + R2.denominador+ " = " + R3.numerador + "/" + R3.denominador);
	}
	
	static Racionales sumaRacionales (Racionales R1, Racionales R2) 
	{
		Racionales R4=new Racionales();
		R4.denominador=(R1.denominador)*(R2.denominador);
		R4.numerador=((R1.numerador)*(R2.denominador))+((R1.denominador)*(R2.numerador));
		
		
		return R4;
	}
	
	
}
