package parte_1;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;
import java.util.TreeSet;

public class Principal {

	public static void main(String[] args) {

		// ****************Declaracion de objetos y variables********************//

		int N = 2500; // cantidad de elementos a ingresar
		long tiempoI, tiempoF;

		TreeSet<Integer> arbolTreeSet = new TreeSet<Integer>();
		LinkedList<Integer> lista = new LinkedList<Integer>();
		ABB arbolABB = new ABB();
		AVL arbolAVL = new AVL();

		Random aleatorio = new Random();

		// **********************************************************************//

		// ******Metodo para llenar arreglo de numeros aleatorios no repetidos******//

		int aux = N;
		int[] numeros = new int[N]; // aqui se guardan los numeros ordenados
		int[] resultado = new int[N]; // Aqui se guardaran los valores aleatorios sin repetir
		int index;

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) // arreglo ordenado del 0 a N-1 (1..N-1)
		{
			numeros[i] = i;
		}

		for (int i = 0; i < N; i++) {
			index = aleatorio.nextInt(aux); // genera un numero aleatorio entre 0 y N-1 y a cada vuelta genera numeros
											// en menor intervalo
			resultado[i] = numeros[index]; // guarda el valor aleatorio en la cadena resultado
			numeros[index] = numeros[aux - 1]; // el ultimo numero de la cadena ordenada es guardado en el lugar donde
												// estaba el numero agregado a la cadena de aleatorios
			aux--; // reduce el auxiliar para no generar aleatorios mayores al rango

		}

		//// se imprime el resultado; //Verificar para saber si verdaderamente los datos
		//// son aleatorios
		// System.out.println("El resultado del arreglo es:");
		// for(int i=0;i<N;i++){
		// System.out.print( resultado[i] + "_" );
		// }

		System.out.println();
		tiempoF = System.currentTimeMillis();

		System.out.println("Tiempo de operacion [Rellenar arreglo de aleatorios]: " + (tiempoF - tiempoI) + "ms"
				+ "  Datos ingresados: " + N);
		System.out.println();
		// **********************************************************************//

		// *********Agregar elementos aleatorios a linked list y ordenar*********//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			lista.add(resultado[i]);

		}

		// System.out.println("LinkedList (desordenado): "+ lista); //verifica si el
		// linked list se lleno con el arreglo de aleatorios

		Collections.sort(lista); // Sirve para ordenar el LinkedList

		tiempoF = System.currentTimeMillis();

		// System.out.println("LinkedList (ordenado): " + lista); //verifica si linked
		// list se ordeno correctamente

		System.out.println("Tiempo de operacion [Insertar LinkedList]: " + (tiempoF - tiempoI) + "ms"
				+ "  Datos ingresados: " + N);

		// **********************************************************************//

		// *****************Agregar elementos aleatorios a ABB*******************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolABB.inserta(resultado[i]);

		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("Arbol ABB en orden: " + arbolABB.Orden()); // sirve para
		// corroborar si se agregaron elemento al ABB

		System.out.println(
				"Tiempo de operacion [Insertar arbol ABB]: " + (tiempoF - tiempoI) + "ms" + "  Datos ingresados: " + N);

		// **********************************************************************//

		// *************Agregar elementos aleatorios a TreeSet*******************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolTreeSet.add(resultado[i]);
		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("Arbol TreeSet (orden): " + arbolTreeSet); //sirve para
		// corroborar si el arbol TreeSet tiene elementos

		System.out.println("Tiempo de operacion [Insertar arbol TreeSet]: " + (tiempoF - tiempoI) + "ms"
				+ "  Datos ingresados: " + N);

		// **********************************************************************//

		// *****************Agregar elementos aleatorios a AVL*******************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolAVL.inserta(resultado[i]);
		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("Arbol AVL: " + arbolAVL.Orden()); sirve para checar que
		// AVL ingresa datos y los muestra en orden

		System.out.println(
				"Tiempo de operacion [Insertar arbol AVL]: " + (tiempoF - tiempoI) + "ms" + "  Datos ingresados: " + N);
		System.out.println();
		// **********************************************************************//

		// *********Buscar elementos de linkedlist*********//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			lista.contains(resultado[i]);

		}

		tiempoF = System.currentTimeMillis();

		System.out.println(
				"Tiempo de operacion [Buscar LinkedList]: " + (tiempoF - tiempoI) + "ms" + "  Datos buscados: " + N);

		// **********************************************************************//

		// *****************Busca elementos en ABB*******************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolABB.busca(resultado[i]);

		}

		tiempoF = System.currentTimeMillis();

		System.out.println(
				"Tiempo de operacion [Buscar arbol ABB]: " + (tiempoF - tiempoI) + "ms" + "  Datos buscados: " + N);

		// **********************************************************************//

		// *******************Busca elementos en TreeSet***********************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolTreeSet.contains(resultado[i]);
		}

		tiempoF = System.currentTimeMillis();

		System.out.println(
				"Tiempo de operacion [Buscar arbol TreeSet]: " + (tiempoF - tiempoI) + "ms" + "  Datos buscados: " + N);

		// **********************************************************************//

		// *****************Busca elementos en AVL*******************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolAVL.busca(resultado[i]);
		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("Arbol AVL vacio: "); //sirve para corroborar que el arbol
		// AVL esta vacio

		System.out.println(
				"Tiempo de operacion [Buscar arbol AVL]: " + (tiempoF - tiempoI) + "ms" + "  Datos buscados: " + N);
		System.out.println();
		// **********************************************************************//

		// *********Eliminar elementos de linkedlist y ordenar*********//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {

			lista.remove(lista.indexOf(resultado[i]));

		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("Lista vacia: "+ lista); //sirve para observar que la
		// lista esta vacia

		System.out.println("Tiempo de operacion [Eliminar LinkedList]: " + (tiempoF - tiempoI) + "ms"
				+ "  Datos eliminados: " + N);

		// **********************************************************************//

		// *****************Eliminar elementos de ABB*******************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolABB.elimina(resultado[i]);

		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("Arbol ABB vacio: "+ arbolABB.Orden()); //sirve para ver
		// si se eliminarion los valores del arbol ABB

		System.out.println(
				"Tiempo de operacion [Eliminar arbol ABB]: " + (tiempoF - tiempoI) + "ms" + "  Datos eliminados: " + N);

		// **********************************************************************//

		// *******************Elimina elementos de TreeSet***********************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			arbolTreeSet.remove(resultado[i]);
		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("TreeSet vacio: "+arbolTreeSet); //sirve para corroborar
		// que TreeSet esta vacio

		System.out.println("Tiempo de operacion [Eliminar arbol TreeSet]: " + (tiempoF - tiempoI) + "ms"
				+ "  Datos Eliminados: " + N);

		// **********************************************************************//

		// *****************Elimina elementos de AVL*******************//

		tiempoI = System.currentTimeMillis();

		for (int i = 0; i < N; i++) {
			// arbolAVL.elimina(resultado[i]);
		}

		tiempoF = System.currentTimeMillis();

		// System.out.println("Arbol AVL vacio: "); //sirve para corroborar que el arbol
		// AVL esta vacio

		System.out.println(
				"Tiempo de operacion [Eliminar arbol AVL]: " + (tiempoF - tiempoI) + "ms" + "  Datos Eliminados: " + N);
		System.out.println();
		// **********************************************************************//

	}// fin del main
}// fin de la clase principal
