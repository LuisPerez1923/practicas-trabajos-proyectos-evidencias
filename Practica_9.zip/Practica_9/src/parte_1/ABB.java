package parte_1;

public class ABB {

	private NodoABB raiz = null;
	private String cadena;

	public class NodoABB {
		int dato;
		NodoABB izq;
		NodoABB der;

		NodoABB(int dato, NodoABB izq, NodoABB der) {
			this.dato = dato;
			this.izq = izq;
			this.der = der;
		}
	}// fin de la clase NodoABB

	///// Metodo para insertar al arbol/////
	void inserta(int dato) {
		raiz = insertaABB(raiz, dato);
	}

	private NodoABB insertaABB(NodoABB arbol, int dato) {
		if (arbol == null) {
			arbol = new NodoABB(dato, null, null);
		} else {
			if (dato < arbol.dato)
				arbol.izq = insertaABB(arbol.izq, dato);
			else
				arbol.der = insertaABB(arbol.der, dato);

		}
		return arbol;
	}

	///// Metodo para acomodar en orden/////

	private String recorreOrden(NodoABB arbol) {
		if (arbol != null) {
			recorreOrden(arbol.izq);
			// System.out.println(arbol.dato);
			cadena = cadena + arbol.dato + " ";
			recorreOrden(arbol.der);
		}
		return cadena;
	}

	String Orden() {
		cadena = "";
		cadena = recorreOrden(raiz);
		return cadena;

	}

	///// Metodo para acomodar en postorden/////

	private String recorrePostOrden(NodoABB arbol) {
		if (arbol != null) {
			recorrePostOrden(arbol.izq);
			// System.out.println(arbol.dato);

			recorrePostOrden(arbol.der);
			cadena = cadena + arbol.dato + " ";
		}
		return cadena;
	}

	String PostOrden() {
		cadena = "";
		cadena = recorrePostOrden(raiz);
		return cadena;

	}

	///// Metodo para acomodar en preorden/////

	private String recorrePreOrden(NodoABB arbol) {
		if (arbol != null) {
			cadena = cadena + arbol.dato + " ";
			recorrePostOrden(arbol.izq);
			// System.out.println(arbol.dato);
			recorrePostOrden(arbol.der);

		}
		return cadena;
	}

	String PreOrden() {
		cadena = "";
		cadena = recorrePreOrden(raiz);
		return cadena;

	}

	///// Metodo para buscar elementos/////

	private boolean buscaElementos(NodoABB arbol, int dato2) {
		if (arbol != null) {
			if (arbol.dato == dato2)
				return true;
			else {
				if (dato2 < arbol.dato)
					return buscaElementos(arbol.izq, dato2);
				else
					return buscaElementos(arbol.der, dato2);
			} // fin del else

		} else
			return false;

	}

	boolean busca(int dato) {
		return buscaElementos(raiz, dato);
	}

	///// Metodo para calcular el maximo/////

	private int encuentraMaximo(NodoABB x) {
		if (x != null) {
			if (x.der == null)
				return x.dato;
			else
				return encuentraMaximo(x.der);

		} else
			return -1000;
	}

	int maximo() {
		return encuentraMaximo(raiz);
	}

	///// Metodo para encontrar el minimo/////

	static int encuentraMinimo(NodoABB x) {
		if (x != null) {
			if (x.izq == null)
				return x.dato;
			else
				return encuentraMinimo(x.izq);

		} else
			return -1000;
	}

	int minimo() {
		return encuentraMinimo(raiz);
	}

	///// Metodo para ordenar en amplitud/////
	//

	//

	//

	//

	//

	//

	//

	//

	//

	///// Metodo para eliminar un nodo/////

	private NodoABB sustituye_el_mayor_de_los_menores(NodoABB a, NodoABB aux) {
		if (a.der != null) {
			a.der = sustituye_el_mayor_de_los_menores(a.der, aux);
		} else {
			aux.dato = a.dato;
			aux = a; // parece innesesario
			a = a.izq;
		}

		return a;
	}

	private NodoABB eliminaABB(NodoABB x, int dato) {
		if (x == null) {
			return null;
		}

		if (dato < x.dato) {
			x.izq = eliminaABB(x.izq, dato);
		}

		else // else 1
		{
			if (dato > x.dato) {
				x.der = eliminaABB(x.der, dato);
			} else // else 2
			{
				if (dato == x.dato)// ya lo encontre!!!
				{
					NodoABB aux;
					aux = x;

					if (x.izq == null) {
						x = x.der;
					} else // tiene izquierdo pero no se sibe si tiene derecho
					{
						if (x.der == null) {
							x = x.izq;
						} else // tiene dos hijos
						{
							x.izq = sustituye_el_mayor_de_los_menores(x.izq, aux);
						}
					} // fin de else tiene izquiero pero no sabemos si tiene derecho
				} // fin del if ya lo encontre!!!
			} // fin de else 2
		} // fin de else 1

		return x;

	}// fin del metodo elmina ABB

	void elimina(int dato) {
		raiz = eliminaABB(raiz, dato);
	}

	///////////////////////////////////////
} // FIN DE LA CLASE ABB
