
package parte_1;


public class AVL {
	
	
	private NodoAVL raiz = null;
	private String cadena;
	
	public class NodoAVL {
		int dato;
		NodoAVL izq;
		NodoAVL der;
		int altura;

		NodoAVL(int dato, NodoAVL izq, NodoAVL der) {
		this.dato = dato;
		this.izq = izq;
		this.der = der;
		}// fin del constructor
	}/// fin e la clase NodoAVL///


//*************************Inserta al arbol AVL*******************//
	
	void inserta(int dato) {
		raiz = insertaAVL(raiz, dato);
		}

	private NodoAVL insertaAVL(NodoAVL arbol, int dato) 
	{
		if (arbol == null) {
		arbol = new NodoAVL(dato, null, null);
		arbol.altura = 0;
		} else {

			if (dato < arbol.dato) {
		arbol.izq = insertaAVL(arbol.izq, dato);

		if ((altura(arbol.izq)) - (altura(arbol.der)) == 2) {
		if (dato < arbol.izq.dato) {
						arbol = rotacionSimpleDer(arbol);
		} else {
		arbol = rotacionDobleIzqDer(arbol);
		}
		}

		else {
		arbol.altura = altura(arbol);
		}
		}

		else {
		if (dato > arbol.dato) {
		arbol.der = insertaAVL(arbol.der, dato);

		if ((altura(arbol.der)) - (altura(arbol.izq)) == 2) {
		if (dato > arbol.der.dato) {
		arbol = rotacionSimpleIzq(arbol);
		} else {
		arbol = rotacionDobleDerIzq(arbol);
		}
		} else {
		arbol.altura = altura(arbol);
		}
		}

		}

		}

		return arbol;

		}//fin metodo inserta AVL
	
//**********************************************************************//
	
	
//************************Metodo rotacion simple derecha****************//
	

		private NodoAVL rotacionSimpleDer(NodoAVL ap) {
		NodoAVL ap1;

		ap1 = ap.izq;
		ap.izq = ap1.der;
		ap1.der = ap;

		ap.altura = altura(ap);
		ap1.altura = altura(ap1);

		ap = ap1;

		return ap;
		}/// fin metodo rotacion simple derecha
		
//**********************************************************************//

//*******************Metodo rotacion simple izquierda*******************//
		

		private NodoAVL rotacionSimpleIzq(NodoAVL ap) {
		NodoAVL ap1;

		ap1 = ap.der;
		ap.der = ap1.izq;
		ap1.izq = ap;

		ap.altura = altura(ap);
		ap1.altura = altura(ap1);

		ap = ap1;

		return ap;
		}/// fin metodo rotacion simple izquierda
		
//**********************************************************************//


//***************Metodo rotacion doble izquierda derecha****************//
		

		private NodoAVL rotacionDobleIzqDer(NodoAVL ap) {
		ap.izq = rotacionSimpleIzq(ap.izq);
		ap = rotacionSimpleDer(ap);

		return ap;
		}// fin del metodo rot dob izq der
		
//**********************************************************************//


//***************Metodo rotacion doble der izquierda********************//

		
		private NodoAVL rotacionDobleDerIzq(NodoAVL ap) {
		ap.der = rotacionSimpleDer(ap.der);
		ap = rotacionSimpleIzq(ap);

		return ap;
		}// fin del metodo rot dob dr izq
		
//**********************************************************************//


//********************Metodo para calcular altura***********************//

		void alturaAVL()
		{
			try {
			raiz.altura=altura(raiz);
			System.out.println("La altura del arbol es " + raiz.altura);
			}
			
			catch(NullPointerException excepcion)
			{
				System.out.println("Arbol apunta a nulo [esta vacio]");
			}
		}
		
		
		private int max(int x, int y) {
		if (x > y)
		return x;
		else
		return y;
		}// fin del metodo max

		private int altura(NodoAVL arbol) {
		if (arbol == null)
		return -1;
		
		else
		return (1 + max(altura(arbol.izq), altura(arbol.der)));

		}// fin del metodo altura
		
//**********************************************************************//


//**********************Metodo elimina AVL******************************//
		
		void elimina(int dato)
		{
			raiz=eliminaAVL(raiz,dato);
		}

		private NodoAVL eliminaAVL(NodoAVL arbol, int dato) 
		{
			if (arbol==null)
			{
				return null;
			}
		       if(arbol!=null)
		       {
		          if(dato<arbol.dato)
		          {   
		           arbol.izq=eliminaAVL(arbol.izq,dato);     
		           arbol=verificaRotacionIzq(arbol);
		          }
		          else 
		          {
		        
		             if(dato>arbol.dato)
		              {	        
		                 arbol.der=eliminaAVL(arbol.der,dato);
		                 arbol=verificaRotacionDer(arbol);
		               }
		          }
		       
		       }
		       
		       return arbol;
		}//fin del metodo elimina


//****************Metodo verifica rotacion a la izquierda***************//


	private	NodoAVL verificaRotacionIzq(NodoAVL arbol)
		{
		  if((altura(subArbolDer(arbol)))-(altura(subArbolIzq(arbol)))==2)
		  {
			  if((altura(subArbolDer(subArbolDer(arbol)))-altura(subArbolIzq(subArbolDer(arbol))))>=0)
			  {
				  arbol=rotacionSimpleIzq(arbol);
			  }
			  else
			  {
				  arbol=rotacionDobleDerIzq(arbol);
			  }
		  }
		  
		  else
		  {
			  arbol.altura=1+ max((altura(subArbolIzq(arbol))),(altura(subArbolDer(arbol))));
		  }
		  return arbol;
		}

//**********************************************************************//

	private	NodoAVL verificaRotacionDer(NodoAVL arbol)
		{
		  if((altura(subArbolIzq(arbol)))-(altura(subArbolDer(arbol)))==2)
		  {
			  if((altura(subArbolIzq(subArbolIzq(arbol)))-altura(subArbolDer(subArbolIzq(arbol))))>=0)
			  {
				  arbol=rotacionSimpleDer(arbol);
			  }
			  else
			  {
				  arbol=rotacionDobleIzqDer(arbol);
			  }
		  }
		  
		  else
		  {
			  arbol.altura=1+ max((altura(subArbolDer(arbol))),(altura(subArbolIzq(arbol))));
		  }
		  return arbol;
		}


//**********************************************************************//
		

//************************Recorre en orden******************************//
		
		private String recorreOrden(NodoAVL arbol) {
			if (arbol != null) {
			recorreOrden(arbol.izq);
			// System.out.println(arbol.dato);
			cadena = cadena + arbol.dato + " ";
			recorreOrden(arbol.der);
			}
			return cadena;
			}

			String Orden() {
			cadena = "";
			cadena = recorreOrden(raiz);
			return cadena;

			}

//**********************************************************************//
			
			
//*********************Metodos subarbol izquierdo y derecho*************//
			
			private NodoAVL subArbolDer(NodoAVL arbol)
			{
				arbol=arbol.der;
				
				return arbol;
			}
			
			
			private NodoAVL subArbolIzq(NodoAVL arbol)
			{
				arbol=arbol.izq;
				
				return arbol;
			}
			
//**********************************************************************//			

			
//********************Metodo busqueda en AVL****************************//
	
			private boolean buscaElementos(NodoAVL arbol, int dato2) {
				if (arbol != null) {
				if (arbol.dato == dato2)
				return true;
				else {
				if (dato2 < arbol.dato)
				return buscaElementos(arbol.izq, dato2);
				else
				return buscaElementos(arbol.der, dato2);
				} // fin del else

				} else
				return false;

				}

				boolean busca(int dato) {
				return buscaElementos(raiz, dato);
				}
			
			
//**********************************************************************//			
}//fin de la clase AVL
