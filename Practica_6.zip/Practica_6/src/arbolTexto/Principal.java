package arbolTexto;

public class Principal {

	public static void main(String[] args) {
		
	NodoAR arbol1= new NodoAR();
	NodoAR arbol2= new NodoAR();
	NodoAR arbol3= new NodoAR();
	
	//ARBOL 1
	
	NodoAR N1,N2,N3,N4,N5,N6,N7;
	
	
	N4=NodoAR.insertarEnArbol(4, null, null);
	N5=NodoAR.insertarEnArbol(5, null, null);
    N6=NodoAR.insertarEnArbol(6, null, null);
	N7=NodoAR.insertarEnArbol(7, null, null);
	N2=NodoAR.insertarEnArbol(2, N4, N5);
	N3=NodoAR.insertarEnArbol(3, N6, N7);
	N1=NodoAR.insertarEnArbol(1, N2, N3);
	
	arbol1=N1;
	
	
		
	System.out.println("El nodo raiz del arbol 1 es: " + NodoAR.nodoRaiz(arbol1));
	
	System.out.println("El numero de nodos del arbol 1 es:  " + NodoAR.cuentaElementos(arbol1));
	
	System.out.println("La altura del arbol 1 es: " + NodoAR.calculaAltura(arbol1));
	
	
	System.out.println("Orden arbol 1 "); NodoAR.recorreEnOrden(arbol1);
	System.out.println(); System.out.println("Preorden arbol 1"); NodoAR.recorreEnPreorden(arbol1);
	System.out.println(); System.out.println("Postorden arbol 1"); NodoAR.recorreEnPostorden(arbol1);
	 System.out.println();
	 System.out.println();
	 
	 //ARBOL 2
	 
	
	 
	 NodoAR NO1,NO2,NO3,NO4,NO5,NO6,NO7,NO8;
		
	    NO8=NodoAR.insertarEnArbol(8, null,null );
	    NO5=NodoAR.insertarEnArbol(5, NO8, null);
	    NO6=NodoAR.insertarEnArbol(6, null, null);
	    NO3=NodoAR.insertarEnArbol(3, NO5, NO6);
		NO4=NodoAR.insertarEnArbol(4, null, null);
		NO2=NodoAR.insertarEnArbol(2, NO3, NO4);
		NO7=NodoAR.insertarEnArbol(7, null, null);
		NO1=NodoAR.insertarEnArbol(1, NO7, NO2);
		
		
		arbol2=NO1;
	
		System.out.println("El nodo raiz del arbol 2 es: " + NodoAR.nodoRaiz(arbol2));
		
		System.out.println("El numero de nodos del arbol 2 es:  " + NodoAR.cuentaElementos(arbol2));
		
		System.out.println("La altura del arbol 2 es: " + NodoAR.calculaAltura(arbol2));
		
		
		System.out.println("Orden arbol 2 "); NodoAR.recorreEnOrden(arbol2);
		System.out.println(); System.out.println("preorden arbol 2 "); NodoAR.recorreEnPreorden(arbol2);
		System.out.println(); System.out.println("Postorden arbol 2 "); NodoAR.recorreEnPostorden(arbol2);
		System.out.println();
		System.out.println();
		 
		
		//ARBOL 3
		 
		 NodoAR NODO1,NODO2,NODO3,NODO4,NODO5,NODO6,NODO7,NODO8;
		
		  NODO8=NodoAR.insertarEnArbol(8, null, null);
		  NODO7=NodoAR.insertarEnArbol(7, NODO8, null);
		  NODO6=NodoAR.insertarEnArbol(6, null, NODO7);
		  NODO5=NodoAR.insertarEnArbol(5, NODO6, null);
		  NODO4=NodoAR.insertarEnArbol(4, null,NODO5);
		  NODO3=NodoAR.insertarEnArbol(3, null,null);
		  NODO2=NodoAR.insertarEnArbol(2, NODO4, NODO3);
		  NODO1=NodoAR.insertarEnArbol(1, NODO2, null);
		  
		  arbol3=NODO1;
				
			System.out.println("El nodo raiz del arbol 3 es: " + NodoAR.nodoRaiz(arbol3));
			
			System.out.println("El numero de nodos del arbol 3 es:  " + NodoAR.cuentaElementos(arbol3));
			
			System.out.println("La altura del arbol 3 es: " + NodoAR.calculaAltura(arbol3));
			
			
			System.out.println("Orden arbol 3 "); NodoAR.recorreEnOrden(arbol3);
			System.out.println(); System.out.println("Preorden arbol 3 ");  NodoAR.recorreEnPreorden(arbol3);
			System.out.println(); System.out.println("Postorden arbol 3 "); NodoAR.recorreEnPostorden(arbol3);
			System.out.println();
			System.out.println();
	}

}
