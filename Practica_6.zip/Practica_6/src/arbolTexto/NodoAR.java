package arbolTexto;

public class NodoAR {
 
	int dato;
	NodoAR izq;
	NodoAR der;
	
	static boolean esVacio(NodoAR x)
	{
		if(x==null)
		{
			return true;
		}
		
		else
			return false;
	}
	
	static NodoAR insertarEnArbol(int dato2, NodoAR izq2, NodoAR der2)
	{
		NodoAR aux=new NodoAR();
		aux.dato=dato2;
		aux.izq=izq2;
	    aux.der=der2;
	 
	   return aux;
	}
	
	static void recorreEnOrden(NodoAR y)
	{
		if(y!=null)
		{
			recorreEnOrden(y.izq);
		    System.out.print(y.dato + " ");
		    recorreEnOrden(y.der);
		}
		
		
	}
	
	static void recorreEnPreorden(NodoAR y)
	{
		System.out.print(y.dato + " ");
		recorreEnOrden(y.izq);
	    recorreEnOrden(y.der);
	  
	}
	
	static void recorreEnPostorden(NodoAR y) 
	{
		if(y!=null)
		{
			recorreEnOrden(y.izq);
		    recorreEnOrden(y.der);
		    System.out.print(y.dato + " ");
		}
		
		
	}
	
	static int cuentaElementos(NodoAR y)
	{
		if(y==null)
		{
			return 0;
		}
		else
		{
			return (1+ cuentaElementos(y.izq) + cuentaElementos(y.der));
		}
	}
	
	static int max(int x, int y)
	{
		if (x>y)
		{
			return x;
		}
		else
		{
			return y;
		}
	}
	
	static int calculaAltura(NodoAR y)
	{
		if(y==null)
		{
			return -1;
		}
		else
		{
			return(1+ max(calculaAltura(y.izq), calculaAltura(y.der)));
		}
	}
	
	static int nodoRaiz(NodoAR y)
	{
		if(y==null)
		{
			return -1;
		}
		else 
		{
			return y.dato;
		}
	}


}
